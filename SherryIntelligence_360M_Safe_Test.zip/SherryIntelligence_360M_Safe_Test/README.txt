SherryIntelligence 360M test lab

Upload the WHOLE test360 FOLDER (with index.html and ai-worker.js inside it) to the ROOT of the existing GitHub Pages repository.
DO NOT replace the original repository root index.html or ai-worker.js.

Test link (adjust for actual repository capitalization):
https://adamsr22.github.io/Sherryintelligence/test360/

Model: HuggingFaceTB/SmolLM2-360M-Instruct, WASM q4
Requires initial model and JS downloads; inference runs in your iPhone browser.
Cannot guarantee Safari will not crash: browser memory limits still apply.
The Reset button terminates the test worker. On a full webpage crash, reopen the original app root URL.
